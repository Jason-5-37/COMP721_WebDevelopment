export class Course {
  course_id: number;
  course_title: string;
  semester: string;
  period: string;
  lecturer: string;
}
